SET max_temporary_non_const_columns = 10;
SELECT number + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 AS x FROM system.numbers LIMIT 1;
