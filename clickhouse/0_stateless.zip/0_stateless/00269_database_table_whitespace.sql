SELECT * FROM system . one;
SELECT * FROM system /* Hello */. `one`;
