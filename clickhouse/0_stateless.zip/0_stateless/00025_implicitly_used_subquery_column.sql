SELECT y FROM (SELECT materialize(1) AS x, x AS y)
