SELECT arrayJoin([[3,4,5], [6,7], [2], [1,1]]) AS x ORDER BY x DESC
