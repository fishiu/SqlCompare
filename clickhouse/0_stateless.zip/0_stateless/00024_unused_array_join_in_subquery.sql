SELECT count() FROM (SELECT 1, arrayJoin([1,2,3]))
