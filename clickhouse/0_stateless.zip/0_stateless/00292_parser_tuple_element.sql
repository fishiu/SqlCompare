SELECT ('a', 'b').2
