SELECT materialize('Hello') LIKE '';
SELECT materialize('Hello') LIKE '%';
SELECT materialize('Hello') LIKE '%%';
SELECT materialize('Hello') LIKE '%%%';
SELECT materialize('Hello') LIKE '%_%';
SELECT materialize('Hello') LIKE '_';
SELECT materialize('Hello') LIKE '_%';
SELECT materialize('Hello') LIKE '%_';

SELECT 'Hello' LIKE '';
SELECT 'Hello' LIKE '%';
SELECT 'Hello' LIKE '%%';
SELECT 'Hello' LIKE '%%%';
SELECT 'Hello' LIKE '%_%';
SELECT 'Hello' LIKE '_';
SELECT 'Hello' LIKE '_%';
SELECT 'Hello' LIKE '%_';

