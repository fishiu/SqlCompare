SELECT arrayMap(x -> 1, [2]), 123 AS x, x + 1;
