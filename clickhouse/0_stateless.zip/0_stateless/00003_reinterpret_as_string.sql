SELECT number FROM system.numbers WHERE reinterpretAsString(number) = 'Ё' LIMIT 1
