SELECT arrayJoin(['Hello', 'Goodbye'])
