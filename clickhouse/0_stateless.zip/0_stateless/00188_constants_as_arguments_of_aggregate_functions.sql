SELECT count(), sum(1), uniq(123) FROM (SELECT * FROM system.numbers LIMIT 10);
