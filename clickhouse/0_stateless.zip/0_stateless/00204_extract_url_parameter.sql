SELECT extractURLParameter('http://com/?testq=aaa&q=111', 'q');
