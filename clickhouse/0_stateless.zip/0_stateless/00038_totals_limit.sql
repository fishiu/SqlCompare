SET enable_positional_arguments = 0;
SELECT count() GROUP BY 1 WITH TOTALS LIMIT 1;
