SELECT materialize('prepre_f') LIKE '%pre_f%';

SELECT materialize('prepre_f') LIKE '%%%pre_f%';
