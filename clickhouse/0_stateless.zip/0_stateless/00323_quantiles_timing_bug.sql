SELECT quantilesTiming(0.99)(arrayJoin(range(100000)));
