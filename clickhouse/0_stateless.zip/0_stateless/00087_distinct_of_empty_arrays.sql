SELECT DISTINCT emptyArrayString() AS k FROM (SELECT * FROM system.numbers LIMIT 100000);
