SELECT toUInt16(toFixedString(toString(number), 3)) FROM system.numbers LIMIT 111
