SELECT match(materialize('Hello'), '');
SELECT match('Hello', '');
